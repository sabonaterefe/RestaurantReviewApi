﻿using Microsoft.AspNetCore.Http;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using BCrypt.Net;

namespace RestaurantReviewApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RestaurantReviewController : ControllerBase
    {
        private readonly IMongoCollection<Restaurant> _restaurantCollection;
        private readonly IMongoCollection<Review> _reviewCollection;
        private readonly IMongoCollection<Order> _orderCollection;
        private readonly IMongoCollection<Category> _categoryCollection;
        private readonly IMongoCollection<User> _userCollection;
        private readonly IMongoCollection<ApiResponse> _apiResponseCollection;

        public User CurrentUser { get; set; }

        public RestaurantReviewController()
        {
            // MongoDB connection setup
                 var connectionString = "mongodb+srv://sabona:sabonastore@cluster0.aoezar8.mongodb.net/RestaurantReview";
                 var client = new MongoClient(connectionString);
                 var database = client.GetDatabase("RestaurantReview");

            // Collection initialization
            _restaurantCollection = database.GetCollection<Restaurant>("restaurants");
            _reviewCollection = database.GetCollection<Review>("reviews");
            _orderCollection = database.GetCollection<Order>("orders");
            _categoryCollection = database.GetCollection<Category>("categories");
            _userCollection = database.GetCollection<User>("users");
            _apiResponseCollection = database.GetCollection<ApiResponse>("apiResponses");
        }

        #region Restaurant Endpoints

        [HttpGet("restaurants")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Restaurant>))]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public ActionResult<IEnumerable<Restaurant>> GetAllRestaurants()
        {
            var restaurants = _restaurantCollection.Find(r => true).ToList();
            return Ok(restaurants);
        }

        [HttpPost("restaurants")]
        [ProducesResponseType(201)]
        [ProducesResponseType(405)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult AddRestaurant([FromBody] Restaurant restaurant)
        {
            _restaurantCollection.InsertOne(restaurant);
            return Ok(restaurant);
        }

        [HttpGet("restaurants/findByStatus")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Restaurant>))]
        [ProducesDefaultResponseType]
        [ProducesResponseType(400)]
        [ProducesResponseType(401)]
        public ActionResult<IEnumerable<Restaurant>> FindRestaurantsByStatus([FromQuery] List<string> status)
        {
            var restaurants = _restaurantCollection.Find(r => status.Contains(r.Status)).ToList();
            return Ok(restaurants);
        }

        [HttpGet("restaurants/{restaurantId}")]
        [ProducesResponseType(200, Type = typeof(Restaurant))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public ActionResult<Restaurant> GetRestaurantById(long restaurantId)
        {
            var restaurant = _restaurantCollection.Find(r => r.Id == restaurantId).FirstOrDefault();
            if (restaurant != null)
            {
                return Ok(restaurant);
            }
            else
            {
                return NotFound("Restaurant not found");
            }
        }

        [HttpPut("restaurants/{restaurantId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult UpdateRestaurant(long restaurantId, [FromBody] Restaurant restaurant)
        {
            var result = _restaurantCollection.ReplaceOne(r => r.Id == restaurantId, restaurant);
            if (result.ModifiedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("restaurants/{restaurantId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult DeleteRestaurant(long restaurantId)
        {
            var result = _restaurantCollection.DeleteOne(r => r.Id == restaurantId);
            if (result.DeletedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        #endregion

        #region Review Endpoints

        [HttpGet("reviews")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Review>))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public ActionResult<IEnumerable<Review>> GetAllReviews()
        {
            var reviews = _reviewCollection.Find(r => true).ToList();
            return Ok(reviews);
        }

        [HttpGet("restaurant/{restaurantId}/reviews")] 
        [ProducesResponseType(200, Type = typeof(IEnumerable<Review>))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public ActionResult<IEnumerable<Review>> GetReviews(long restaurantId, int? offset, int? limit, string orderby, string order)
        {
            try
            {
                var reviewsQuery = _reviewCollection.Find(r => r.RestaurantId == restaurantId);

                if (offset.HasValue)
                    reviewsQuery = reviewsQuery.Skip(offset.Value);

                if (limit.HasValue)
                    reviewsQuery = reviewsQuery.Limit(limit.Value);

                var reviews = reviewsQuery.ToList();
                return Ok(reviews);
            }
            catch (Exception)
            {
                return StatusCode(500, "Error retrieving the reviews.");
            }
        }

        [HttpPost("reviews")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult AddReview([FromBody] Review review)
        {
            try
            {
                _reviewCollection.InsertOne(review);
                return Ok(review);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error adding the review: {ex.Message}");
            }
        }

        [HttpPut("reviews/{reviewId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult UpdateReview(long reviewId, [FromBody] Review review)
        {
            var result = _reviewCollection.ReplaceOne(r => r.Id == reviewId, review);
            if (result.ModifiedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("reviews/{reviewId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult DeleteReview(long reviewId)
        {
            var result = _reviewCollection.DeleteOne(r => r.Id == reviewId);
            if (result.DeletedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        #endregion

        #region Order Endpoints

        [HttpPost("orders")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult PlaceOrder([FromBody] Order order)
        {
            try
            {
                if (IsValidOrder(order))
                {
                    _orderCollection.InsertOne(order);
                    return Ok(order);
                }
                return BadRequest("Invalid order details.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error processing the order: {ex.Message}");
            }
        }

        [HttpGet("orders")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Order>))]
        [ProducesResponseType(400)]
        [ProducesResponseType(401)]
        public ActionResult<IEnumerable<Order>> GetOrders()
        {
            var orders = _orderCollection.Find(o => true).ToList();
            return Ok(orders);
        }

        [HttpGet("orders/{orderId}")]
        [ProducesResponseType(200, Type = typeof(Order))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public ActionResult<Order> GetOrderById(long orderId)
        {
            var order = _orderCollection.Find(o => o.Id == orderId).FirstOrDefault();
            if (order != null)
            {
                return Ok(order);
            }
            else
            {
                return NotFound("Order not found");
            }
        }

        [HttpPut("orders/{orderId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult UpdateOrder(long orderId, [FromBody] Order order)
        {
            var result = _orderCollection.ReplaceOne(o => o.Id == orderId, order);
            if (result.ModifiedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("orders/{orderId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult DeleteOrder(long orderId)
        {
            var result = _orderCollection.DeleteOne(o => o.Id == orderId);
            if (result.DeletedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        #endregion

        [HttpPost("user")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult AddUser([FromBody] User user)
        {
            _userCollection.InsertOne(user);
            return Ok(user);
        }

        [HttpGet("users/{userId}")]
        [ProducesResponseType(200, Type = typeof(User))]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public ActionResult<User> GetUserById(long userId)
        {
            var user = _userCollection.Find(u => u.Id == userId).FirstOrDefault();
            if (user != null)
            {
                return Ok(user);
            }
            else
            {
                return NotFound("User not found");
            }
        }

        [HttpPut("users/{userId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult UpdateUser(long userId, [FromBody] User user)
        {
            var result = _userCollection.ReplaceOne(u => u.Id == userId, user);
            if (result.ModifiedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("users/{userId}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult DeleteUser(long userId)
        {
            var result = _userCollection.DeleteOne(u => u.Id == userId);
            if (result.DeletedCount == 0)
            {
                return NotFound();
            }
            return NoContent();
        }

        private bool IsValidOrder(Order order)
        {
            return order != null &&
                   order.Quantity > 0 &&
                   !string.IsNullOrEmpty(order.ShipDate) &&
                   IsValidOrderStatus(order.Status);
        }

        private bool IsValidOrderStatus(string status)
        {
            return !string.IsNullOrEmpty(status) &&
                   (status.Equals("placed", StringComparison.OrdinalIgnoreCase) ||
                    status.Equals("approved", StringComparison.OrdinalIgnoreCase) ||
                    status.Equals("delivered", StringComparison.OrdinalIgnoreCase));
        }

        [HttpPost("user/login")]
        [ProducesResponseType(200, Type = typeof(User))]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        public IActionResult LoginUser([FromBody] User loginUser)
        {
            var user = _userCollection.Find(u => u.Username == loginUser.Username).FirstOrDefault();

            if (user != null && BCrypt.Net.BCrypt.Verify(loginUser.PasswordHash, user.PasswordHash))
            {
                CurrentUser = user;
                return Ok(user);
            }

            return BadRequest("Invalid username or password");
        }

        [HttpPost("user/logout")]
        [ProducesResponseType(200, Type = typeof(ApiResponse))]
        [ProducesResponseType(401)]
        [ProducesDefaultResponseType]
        public IActionResult LogoutUser()
        {
            if (CurrentUser != null)
            {
                CurrentUser = null;
                return Ok(new ApiResponse { Code = 200, Type = "OK", Message = "Logout successful" });
            }

            return Unauthorized();
        }

        [HttpGet("categories")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Category>))]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public ActionResult<IEnumerable<Category>> GetCategories()
        {
            var categories = _categoryCollection.Find(c => true).ToList();
            return Ok(categories);
        }

        [HttpPost("categories")]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesDefaultResponseType]
        [ProducesResponseType(401)]
        public IActionResult AddCategory([FromBody] Category category)
        {
            _categoryCollection.InsertOne(category);
            return Ok(category);
        }

        [HttpGet("user/orders")]
        [ProducesResponseType(200, Type = typeof(IEnumerable<Order>))]
        [ProducesResponseType(401)]
        [ProducesDefaultResponseType]
        public ActionResult<IEnumerable<Order>> GetUserOrders()
        {
            if (CurrentUser != null)
            {
                var userOrders = _orderCollection.Find(o => o.UserId == CurrentUser.Id).ToList();
                return Ok(userOrders);
            }

            return Unauthorized();
        }
      public class Restaurant
{
    [BsonId]
    [BsonRepresentation(BsonType.Int64)]
    public long Id { get; set; }
    public object Category { get; set; }
    public string Name { get; set; }
    public List<Review> Reviews { get; set; }
    public string Status { get; set; }
    public string Image { get; set; }
}

public class Review
{
    [BsonId]
    [BsonRepresentation(BsonType.Int64)]
    public long Id { get; set; }
    public long RestaurantId { get; set; }
    public string ReviewerName { get; set; }
    public string Comment { get; set; }
    public int Rating { get; set; }
}

public class Order
{
    [BsonId]
    [BsonRepresentation(BsonType.Int64)]
    public long Id { get; set; }
    public long RestaurantId { get; set; }
    public long UserId { get; set; } 
    public int Quantity { get; set; }
    public string ShipDate { get; set; }
    public string Status { get; set; }
    public bool Complete { get; set; }
}

public class Category
{
    [BsonId]
    [BsonRepresentation(BsonType.Int64)]
    public long Id { get; set; }
    public string Name { get; set; }
}

public class User
{
    [BsonId]
    [BsonRepresentation(BsonType.Int64)]
    public long Id { get; set; }
    public string Username { get; set; }
    public string PasswordHash { get; set; }
}

public class ApiResponse
{
    [BsonId]
    [BsonRepresentation(BsonType.Int32)]
    public int Code { get; set; }
    public string Type { get; set; }
    public string Message { get; set; }
}
    }
}
